#include<bits/stdc++.h>
using namespace std;
const int INF=1e9+7;
int C[1001][1001];
int dist[1001];
bool vis[1001];
int path[1001];



void Dijkstra(int n,int s){
    for(int i=1;i<=n;i++){
        dist[i]=INF;
        vis[i]=false;
    }
    dist[s]=0;
    path[s]=0;
    for(int i=1;i<=n;i++){
        int u=-1;
        for(int j=1;j<=n;j++){
            if(!vis[j]&&(u==-1||dist[u]>dist[j])){
                u=j;
            }
        }
        vis[u]=true;
        for(int v=1;v<=n;v++){
            if(!vis[v]&&C[u][v]){
                if(dist[v]>dist[u]+C[u][v]){
                    dist[v]=dist[u]+C[u][v];
                    path[v]=u;
                }
            }
        }
    }
}


int main(){
   
   //doc file 
    ifstream fin("input.txt"); 
    if(!fin){
        cout << "khong mo duoc file!";
        return 0;
    }

    int n, s;
    fin >> n >> s;

    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            fin >> C[i][j];
            if(C[i][j]<0) C[i][j]=INF;
        }
    }

    fin.close(); 




	//tim duong di  
    Dijkstra(n, s);




	//ghi file 
    ofstream fout("output.txt"); 

    if(!fout){
        cout << "loi in ra file!";
        return 0;
    }

	//ket qua 
    for(int i=1;i<=n;i++){
        if(dist[i] == INF){
            fout << "v" << s << "->v" << i << ":Khong co duong di." << endl;
        }
        else{
            fout << "v" << s << "->v" << i << ": v" << i;
            int cur = i;
            while(path[cur] != 0){
                fout << "<-" << "v" << path[cur];
                cur = path[cur];
            }
            fout << ", do dai la " << dist[i] << endl;
        }
    }



    fout.close(); 

    return 0;
}

