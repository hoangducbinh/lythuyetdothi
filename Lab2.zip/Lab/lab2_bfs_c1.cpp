#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;

const int MAXN = 100;
int N, v0;
int A[MAXN][MAXN];
bool Visited[MAXN];

void ReadInput() {
    ifstream fin("DOTHI.INP");
    fin >> N >> v0;
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            fin >> A[i][j];
        }
    }
    fin.close();
}

void BFS(int s) {
    queue<int> Q;
    vector<int> result;

    Q.push(s);
    Visited[s] = true;

    while (!Q.empty()) {
        int u = Q.front();
        Q.pop();
        result.push_back(u);

        for (int v = 1; v <= N; v++) {
            if (A[u][v] == 1 && !Visited[v]) {
                Q.push(v);
                Visited[v] = true;
            }
        }
    }

    cout << "Thu tu tham cac dinh xuat phat tu " << s << ": ";
    for (int i = 0; i < result.size(); i++) {
        cout << result[i] << " ";
    }
    cout << endl;
}

int main() {
    ReadInput();

    for (int i = 1; i <= N; i++) {
        Visited[i] = false;
    }

    BFS(v0);

    return 0;
}

