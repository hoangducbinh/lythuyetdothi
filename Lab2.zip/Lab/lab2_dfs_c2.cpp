#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

const int MAX_M = 1000;
const int MAX_N = 1000;

int m, n;
int image[MAX_M][MAX_N];
bool visited[MAX_M][MAX_N];

int dx[] = {-1, 0, 1, 0}; // cac huong dic huyen (tr�n, phai, duoi, trai)
int dy[] = {0, 1, 0, -1};

// H�m DFS de loang theo chieu sau dem dien tich cua vung
void DFS(int x, int y, int& area) {
    visited[x][y] = true;
    area++;

    for (int i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];

        if (nx >= 0 && nx < m && ny >= 0 && ny < n && image[nx][ny] == 1 && !visited[nx][ny]) {
            DFS(nx, ny, area);
        }
    }
}

int main() {
    // doc du lieu tu file vao mang image
    ifstream fin("IMAGE.INP");
    fin >> m >> n;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            fin >> image[i][j];
        }
    }
    fin.close();

    // duyet anh va tim so vung va dien tich cua vung
    int num_regions = 0;
    vector<int> areas;
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            if (image[i][j] == 1 && !visited[i][j]) {
                int area = 0;
                DFS(i, j, area);
                num_regions++;
                areas.push_back(area);
            }
        }
    }

    // In ket qua ra man hinh  
    cout << "So vung: " << num_regions << endl;
    cout << "Dien tich cac vung: ";
    for (int i = 0; i < areas.size(); i++) {
        cout << areas[i] << " ";
    }
    cout << endl;

    // ghi ket qua vao file
    ofstream fout("IMAGE.OUT");
    fout << "So vung: " << num_regions << endl;
    fout << "Dien tich cac vung: ";
    for (int i = 0; i < areas.size(); i++) {
        fout << areas[i] << " ";
    }
    fout << endl;
    fout.close();

    return 0;
}

