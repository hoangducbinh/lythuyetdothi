#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <fstream>
#define MaxN 100

using namespace std;

int n;
int A[100][100];
int Daxet[MaxN];

void Init() {
    for(int i = 0; i < n; i++) {
        Daxet[i] = 0;
    }
}

void Read_File() {
    ifstream f("Dothi.INP");
    f >> n;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            f >> A[i][j];
        }
    }
    f.close();
}

void DFS(int u) {
    Daxet[u] = 1;
    cout << u + 1 << " ";
    ofstream f("DOTHI.OUT", ios::app);
    f << u + 1 << " ";
    f.close();
    for(int v = 0; v < n; v++) {
        if(A[u][v] == 1 && !Daxet[v]) {
            DFS(v);
        }
    }
}

void FindReachableVertices(int u) {
    Init();
    DFS(u);
    for(int i = 0; i < n; i++) {
        if(Daxet[i] == 0) {
            cout << "\nKhong co duong di tu dinh " << u + 1 << " den dinh " << i + 1 << "\n";
            ofstream f("DOTHI.OUT", ios::app);
            f << "\nKhong co duong di tu dinh " << u + 1 << " den dinh " << i + 1 << "\n";
            f.close();
        }
    }
}

void Process() {
    int u;
    cout << "Nhap dinh bat dau: ";
    cin >> u;
    FindReachableVertices(u - 1);
}

int main() {
    Read_File();
    Process();
    return 0;
}


