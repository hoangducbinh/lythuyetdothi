#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;

const int MAXN = 100;
int N, v0, v1;
int A[MAXN][MAXN];
bool Visited[MAXN];
int Path[MAXN];

void ReadInput() {
    ifstream fin("DOTHI.INP");
    fin >> N >> v0 >> v1;
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            fin >> A[i][j];
        }
    }
    fin.close();
}

void BFS(int s) {
    queue<int> Q;
    vector<int> result;

    Q.push(s);
    Visited[s] = true;

    while (!Q.empty()) {
        int u = Q.front();
        Q.pop();

        for (int v = 1; v <= N; v++) {
            if (A[u][v] == 1 && !Visited[v]) {
                Q.push(v);
                Visited[v] = true;
                Path[v] = u;
                if (v == v1) {
                    return;
                }
            }
        }
    }
}

void PrintPath() {
    vector<int> path;
    int v = v1;
    while (v != v0) {
        path.push_back(v);
        v = Path[v];
    }
    path.push_back(v0);
    cout << "Duong di ngan nhat tu " << v0 << " den " << v1 << ": ";
    for (int i = path.size()-1; i >= 0; i--) {
        cout << path[i] << " ";
    }
    cout << endl;
}

int main() {
    ReadInput();

    for (int i = 1; i <= N; i++) {
        Visited[i] = false;
        Path[i] = 0;
    }

    BFS(v0);

    PrintPath();

    return 0;
}

